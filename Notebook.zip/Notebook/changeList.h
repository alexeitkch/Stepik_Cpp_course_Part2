#pragma once
#include "definitions.h"
void addContact(Person*&, int&);
void delContact(Person*&, int&);