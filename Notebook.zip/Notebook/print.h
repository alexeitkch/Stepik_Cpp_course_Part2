#pragma once
#include "definitions.h"
void print(Person*);
void printList(Person*, int);
void printSort(Person*, int);