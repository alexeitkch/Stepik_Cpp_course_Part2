#pragma once
#include "definitions.h"
void findContact(Person*, int);
void findBirthdays(Person*, int);